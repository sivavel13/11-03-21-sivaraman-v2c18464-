class Enumex{  
enum val{   
MATHS(5), JAVA(10), PYTHON(15), C(20);   
  
private int value;  
private val(int value){  
this.value=value;  
}  
}  
public static void main(String args[]){  
for (val s : val.values())  
System.out.println(s+" "+s.value);  
  
}}  