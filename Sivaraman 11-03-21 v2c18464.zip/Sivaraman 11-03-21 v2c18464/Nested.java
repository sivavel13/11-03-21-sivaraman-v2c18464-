class Outer{  
 private int data=900;  
 class Inner{  
  void msg()
  {
	  System.out.println("data is "+data); 
  }
 }  
}
 




public class Nested {

	public static void main(String args[])
	{  
		  Outer obj=new Outer();  
		 Outer.Inner in=obj.new Inner();  
		  in.msg();  
		 } 
}
		 

