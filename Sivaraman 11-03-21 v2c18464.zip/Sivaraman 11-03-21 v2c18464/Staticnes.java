class Staticnes
{  
  static int t=7;  
  static class Inner
  {  
   static void msg()
   {
	   System.out.println("data is "+t);
	   }  
  }  
  public static void main(String args[]){  
  Staticnes.Inner.msg();
  }  
}  