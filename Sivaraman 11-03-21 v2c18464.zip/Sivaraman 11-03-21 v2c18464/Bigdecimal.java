import java.math.BigDecimal;

public class Bigdecimal    
{      
    public static void main(String[] args)     
    {      
         
        BigDecimal Var1, Var2;     
        
        int integerValue1, integerValue2;      
      
              
        Var1 = new BigDecimal("-8799");   
        Var2 = new BigDecimal("89665");  
      
           
        integerValue1 = Var1.intValue();      
        integerValue2=Var2.intValueExact();  
      
              
        System.out.println( "Returned int value is = "+integerValue1);  
         
        System.out.println("Returned Exact Integer Value of " +Var2 + " is = " + integerValue2);   
    }      
}    